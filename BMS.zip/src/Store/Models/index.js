import LoginModel from "./Login";
import TestModel from "./Test";
import AppModel from "./App";

export default {
	test: TestModel,
	login: LoginModel,
	app: AppModel
};
