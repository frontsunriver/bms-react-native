export default {
  type: {
    primary: 'Lato-Regular',
    secondary: 'OpenSans-Regular',
    bold: 'Lato-Bold',
    stylish: 'GreatVibes-Regular',
    italic: 'GentiumBookBasic-Italic',
  },
};
