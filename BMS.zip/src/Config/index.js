export const APP_PREFIX = "bms://";
export const BASE_URL = "http://10.0.2.2/bms/api/";
export const DOWNLOAD_URL = "http://10.0.2.2/bms/";
// export const BASE_URL = "https://www.smartoa.co.uk/api/";
// export const DOWNLOAD_URL = "https://www.smartoa.co.uk/";