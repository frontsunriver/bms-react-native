module.exports = {
  assets: ['./src/Assets/fonts'],
  dependencies: {
    'react-native-code-push': {
      platforms: {
        ios: null,
        android: null,
      },
    },
  },
};
